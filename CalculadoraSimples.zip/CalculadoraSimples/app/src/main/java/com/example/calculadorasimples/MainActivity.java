package com.example.calculadorasimples;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button buttonDiv,buttonMult,buttonSoma,buttonSub;
    EditText editTextvalor1,editTextvalor2,editTextTotal;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //componnent buttons and text
        associaComponentesJavaXml();
        buttonSoma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                operacao("+");

            }
        });
        buttonSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                operacao("-");

            }
        });
        buttonMult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                operacao("*");

            }
        });
        buttonDiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                operacao("/");

            }
        });
    }

    private void operacao(String op) {
        double valor1 = Double.parseDouble(editTextvalor1.getText().toString());
        double valor2 = Double.parseDouble(editTextvalor2.getText().toString());
        double total = 0;
        if (op.equals("+")) {
            total = valor1 + valor2;
        } else if (op.equals("-")) {
            total = valor1 - valor2;

        } else if (op.equals("*")) {
            total = valor1 * valor2;

        } else if (op.equals("/")) {
            total = valor1 / valor2;

        } else{
            Toast.makeText(MainActivity.this, "Opcao invalida", Toast.LENGTH_SHORT).show();
            }
//                AlertDialog.Builder msg = new AlertDialog.Builder(MainActivity.this);
//                msg.setMessage("Resultado:" + total);
//                msg.setNeutralButton("OK",null);
//                msg.show();
            editTextTotal.setText(total+"");

    }

    private void associaComponentesJavaXml() {
        buttonDiv = findViewById(R.id.btnDiv);
        buttonMult = findViewById(R.id.btnMulti);
        buttonSoma = findViewById(R.id.btnSoma);
        buttonSub = findViewById(R.id.btnSub);
        editTextvalor1 = findViewById(R.id.editTextValor1);
        editTextvalor2 = findViewById(R.id.editTextValor2);
        editTextTotal = findViewById(R.id.editTextTotal);

    }

}